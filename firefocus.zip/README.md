# For create this extension I use npm
install NODE from https://nodejs.org/en/download/prebuilt-installer
and run `npm install -g npm` for install npm
I use windows 11

run from work path `npm run build-extension` it`s create build of extension
run firefox and go to `about:debugging` go to `This Firefox` and `Load Temporary Add-on..` and run extension


fire