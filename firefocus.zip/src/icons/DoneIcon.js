import React from 'react';

class DoneIcon extends React.Component {
    render(){
        return (
            <div className='doneIcon'>
                <span className='line1'></span>
                <span className='line2'></span>
            </div>
          );
    }

}

export default DoneIcon;
