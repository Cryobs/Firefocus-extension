import React from 'react';

class AddIcon extends React.Component {
    render(){
        return (
            <div className='addBtn-container'>
                <span className='addBtn'>
                    <span className='line1'></span>
                    <span className='line2'></span>
                </span>
            </div>
          );
    }

}

export default AddIcon;
